/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientedistribuidos;

/**
 *
 * @author Dexter
 */
public class Util {
    public static final String LibreriaA                    = "10.2.126.79";    //ip gabriela
    public static final String LibreriaB                    = "10.2.126.86";    //ip dexter windows
    public static final String LibreriaC                    = "10.2.127.251";   //ip dexter ubuntu
    public static final String Biblioteca                            = "A";
    //public static final String Biblioteca                            = "B";
    //public static final String Biblioteca                            = "c";
}
